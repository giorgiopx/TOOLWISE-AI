import { defineConfig } from 'astro/config';
import sitemap from '@astrojs/sitemap';

// Set SITE_URL in Netlify to the real production URL (Netlify URL first, custom domain later).
const site = process.env.SITE_URL || undefined;

export default defineConfig({
  ...(site ? { site } : {}),
  integrations: [sitemap()],
});
